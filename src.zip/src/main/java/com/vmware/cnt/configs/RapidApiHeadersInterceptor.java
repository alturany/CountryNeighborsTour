package com.vmware.cnt.configs;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RapidApiHeadersInterceptor implements RequestInterceptor {
    @Value("${rapid.api.key}")
    private String rapidAPIKey;

    @Override
    public void apply(RequestTemplate template) {
        template.header("x-rapidapi-key", rapidAPIKey);
        template.header("x-rapidapi-host", "restcountries-v1.p.rapidapi.com");
    }
}