package com.vmware.cnt.services;

import com.vmware.cnt.apis.CountryAPI;
import com.vmware.cnt.models.Country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class CountryService {
    @Autowired
    CountryAPI countryAPI;

    @Cacheable(value="countries", key="#countryCode.toUpperCase()" )
    public Country getCountry(String countryCode) {
        return countryAPI.getCountry(countryCode).orElseThrow();
    }

    public String getCurrency(String countryCode){
        //The assumption that I will use single currency for multi currency countries
        return this.getCountry(countryCode).getCurrencies()[0];
    }
}
