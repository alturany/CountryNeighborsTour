package com.vmware.cnt.controllers;

import com.vmware.cnt.models.Country;
import com.vmware.cnt.services.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @Autowired
    CountryService countryService;

    @GetMapping("/{countryCode}")
    public Country getCountry(@PathVariable String countryCode) {
        return countryService.getCountry(countryCode);
    }

}
