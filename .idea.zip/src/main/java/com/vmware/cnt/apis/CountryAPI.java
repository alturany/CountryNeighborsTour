package com.vmware.cnt.apis;

import com.vmware.cnt.models.Country;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Optional;

@FeignClient(value = "rest-countries-v1", url = "https://restcountries-v1.p.rapidapi.com")
public interface CountryAPI {
    @RequestMapping(method = RequestMethod.GET, value = "/alpha/{code}")
    Optional<Country> getCountry(@PathVariable String code);

}
