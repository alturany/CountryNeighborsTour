package com.vmware.cnt.models;

import lombok.Data;

@Data
public class Country {
    private String name;
    private String alpha2Code;
    private String[] borders;
    private String[] currencies;
}
